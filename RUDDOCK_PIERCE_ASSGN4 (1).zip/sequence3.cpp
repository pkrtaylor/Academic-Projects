//
// Created by Kenneth on 3/18/2019.
//

#include "sequence3.h"

namespace main_savitch_5{

    sequence::sequence()
    {
        head_ptr= NULL;
        tail_ptr= NULL;
        cursor= NULL;
        precursor= NULL;
        many_nodes= 0;
    }
    void sequence::start()
    {
        if(head_ptr==NULL)
        {
            cursor=NULL;
            precursor=NULL;
        }
        else
        {
            precursor = NULL;
            cursor=head_ptr;
        }
    }
    void sequence::advance()
    {   assert(is_item());
        precursor=cursor;
        cursor=cursor->link();
    }
    void sequence::insert(const main_savitch_5::sequence::value_type &entry)
    {
        if (head_ptr == NULL)
        {
            list_head_insert(head_ptr, entry);
            tail_ptr = head_ptr;
            cursor = head_ptr;
            precursor = NULL;
            many_nodes++;
        }

        else if (cursor == NULL || precursor == NULL)
        {
            list_head_insert(head_ptr, entry);
            cursor = head_ptr;
            precursor = NULL;
            many_nodes++;

        }
        else
            {
            list_insert(precursor, entry);
            cursor = precursor -> link();
            many_nodes++;
        }

    }

    void sequence::attach(const main_savitch_5::sequence::value_type &entry)
    {
        if(head_ptr== NULL)
        {
            list_head_insert(head_ptr, entry);
            tail_ptr = head_ptr;
            cursor= head_ptr;
            precursor= NULL;
            many_nodes++;
        }
        else if(cursor == NULL || cursor == tail_ptr)
        {
            list_insert(tail_ptr, entry);
            precursor = tail_ptr;
            tail_ptr = tail_ptr -> link();
            cursor = tail_ptr;
            many_nodes++;

        }
        else
        {
            list_insert(cursor, entry);
            precursor = cursor;
            cursor = cursor -> link();
            many_nodes++;


        }
    }
    void sequence::remove_current( )
    {
        assert(is_item());
        if(cursor == head_ptr)
        {
            if(many_nodes == 1)
            {
                list_head_remove(head_ptr);
                precursor = NULL;
                cursor = NULL;
                head_ptr = NULL;
            }
            else
            {
                node* tmp = head_ptr;
                head_ptr = head_ptr->link();
                delete (tmp);
                cursor = head_ptr;
                precursor = NULL;
            }
        }
        else
        {
            cursor = cursor -> link();
            list_remove(precursor);
        }

        --many_nodes;
    }
    void sequence::operator=(const main_savitch_5::sequence &source)
    {
        if(this == &source)
        {
            return;
        }
        else
        {
            list_copy(source.head_ptr, head_ptr, tail_ptr);
            if(source.precursor == NULL)
            {
                if(source.cursor == NULL)
                {
                    cursor = NULL;
                    precursor = NULL;
                }
                else
                {
                    cursor = head_ptr;
                    precursor = NULL;
                }
            }
            else
            {
                node *tmp_ptr = head_ptr;
                node *source_ptr = source.head_ptr;
                while(source_ptr != source.precursor)
                {
                    source_ptr = source_ptr -> link();
                    tmp_ptr = tmp_ptr -> link();
                }
                cursor = tmp_ptr -> link();
                precursor = tmp_ptr;
            }
        }
        many_nodes = source.many_nodes;


    }
        sequence::~sequence()
        {
            list_clear(head_ptr);
            many_nodes = 0;

        }
    sequence::sequence(const sequence& source)

{
    if (source.cursor == NULL)
    {
        list_copy(source.head_ptr, head_ptr, tail_ptr);
        cursor = NULL;
        precursor = NULL;
    }
       
    else if (source.cursor==source.head_ptr)
    {
        list_copy(source.head_ptr, head_ptr, tail_ptr);
        cursor = head_ptr;
        precursor = NULL;
    }
    else
    {

        list_piece(source.head_ptr, source.precursor, head_ptr, precursor);
        list_piece(source.cursor, NULL, cursor, tail_ptr);

        precursor->set_link(cursor);
    }

    many_nodes = source.many_nodes;
    return;

}

































}